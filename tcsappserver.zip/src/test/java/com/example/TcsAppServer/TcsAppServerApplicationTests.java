package com.example.TcsAppServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TcsAppServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
