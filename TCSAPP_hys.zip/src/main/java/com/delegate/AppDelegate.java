package com.delegate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class AppDelegate {
    @Bean
    @LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
    @Autowired
    RestTemplate restTemplate;
    
    
    @HystrixCommand(fallbackMethod = "callAtServiceFail" , commandProperties = {
    		@HystrixProperty(name="execution.isolation.thread.timeoutInMiliseconds", value="2000"),
    		@HystrixProperty(name="execution.isolation.strategy", value="SEMAPHORE")
    },ignoreExceptions = {Exception.class})
    public String callEmployee(String compLocation) {
    	
    	String response= restTemplate.exchange("http://emp-service/getemployees/{compLocation}"
    			,HttpMethod.GET
    			,null
    			,new ParameterizedTypeReference<String>() {
				},compLocation).getBody();
    			
    			
    			return "response recieved " + compLocation + " " + response;
    }
    
    public String callAtServiceFail(String compLocation) {
    	System.out.println("circuit breaker enabled");
    	
    	return "circuit breaker enabled .....service is  down ...try after sometime";
    	
    }
    
	
}
