package com.example.TSCGraphQl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TscGraphQlApplicationTests {

	@Test
	void contextLoads() {
	}

}
