package com.vinsguru.events.order;

public enum OrderStatus {

    ORDER_CREATED,
    ORDER_CANCELLED,
    ORDER_COMPLETED

}