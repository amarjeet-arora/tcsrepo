package com.example.PhotoAppAPIConfigServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoAppApiConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
