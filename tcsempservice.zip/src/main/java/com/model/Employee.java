package com.model;

public class Employee {
	
	private String name;
	private String proName;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String name, String proName) {
		super();
		this.name = name;
		this.proName = proName;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", proName=" + proName + "]";
	}

}
