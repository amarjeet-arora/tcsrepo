package com.service;

 import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.model.Employee;

@RestController
public class EmployeeService {

	private static Map<String, List<Employee>> empDB= new HashMap<String, List<Employee>>();
	
	static {
		empDB= new HashMap<String, List<Employee>>();
		List<Employee> lst= new ArrayList<Employee>();
		Employee  emp= new Employee("emp1","finance");
		lst.add(emp);
		emp= new Employee("emp2","HRMS");
		lst.add(emp);
		empDB.put("tcsindia", lst);
		
		lst= new ArrayList<Employee>();
		emp= new Employee("emp3","Hospitality");
		lst.add(emp);
		emp= new Employee("emp4","Healthcare");
		lst.add(emp);
		empDB.put("tcsUS", lst);
		}
	
	@GetMapping("/getemployees/{empname}")
	public List<Employee> getEmployees(@PathVariable("empname")String name){
		
		List<Employee> empList = empDB.get(name);
		
		if(empList ==null) {
			empList = new ArrayList<Employee>();
			Employee e= new Employee("NOT Found", "N/A");
			empList.add(e);
		}
		return empList;
		
	}
	
	
}
