package com.example.TcsEmployeeService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TcsEmployeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
