package com.delegate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AppDelegate {
    @Bean
    @LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
    @Autowired
    RestTemplate restTemplate;
    
    
    public String callEmployee(String compLocation) {
    	
    	String response= restTemplate.exchange("http://emp-service/getemployees/{compLocation}"
    			,HttpMethod.GET
    			,null
    			,new ParameterizedTypeReference<String>() {
				},compLocation).getBody();
    			
    			
    			return "response recieved " + compLocation + " " + response;
    }
    
    
	
}
