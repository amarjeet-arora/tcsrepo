package com.example.TcsApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TcsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
