package com.jpaboot.inheritance.joinedtable;

import javax.persistence.Entity;

@Entity
class Teacher extends Person {
}
