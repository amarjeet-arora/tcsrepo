package com.jpabootinheritance.onetableperclass;

import javax.persistence.Entity;

@Entity
class Motorcycle extends Vehicle {
    private boolean hasSideCar;

    public boolean hasSideCar() {
        return hasSideCar;
    }
}
